CREATE TABLE Account_master
(
Account_no NUMBER(10) PRIMARY KEY,
Account_type VARCHAR2(25),
Account_Balance NUMBER(15),
Open_date DATE
);


CREATE TABLE Customer
(
Account_no NUMBER(10) PRIMARY KEY,
customer_name VARCHAR2(50),
email VARCHAR2(30),
address VARCHAR2(100),
pancard VARCHAR2(15)
);

CREATE TABLE Transactions
(
transaction_id NUMBER(10) PRIMARY KEY,
tran_description VARCHAR2(100),
DateofTransaction DATE,
TransactionType VARCHAR2(1),
TranAmount NUMBER(15),
Account_no NUMBER(10) REFERENCES Customer(Account_no)
);

CREATE TABLE Service_Tracker
(
service_id NUMBER PRIMARY KEY,
service_description VARCHAR2(100),
account_id number REFERENCES Customer(Account_no),
service_raised_date DATE,
service_status VARCHAR2(20)
);

CREATE TABLE user_table
(
account_id NUMBER REFERENCES Customer(Account_no),
user_id number PRIMARY KEY,
login_password VARCHAR2(50),
secret_question VARCHAR2(50),
secret_answer VARCHAR2(50),
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(1)
);


CREATE TABLE Fund_Transfer
(
FundTransfer_ID NUMBER PRIMARY KEY,
Account_ID NUMBER(10) REFERENCES Account_master(Account_no),
Payee_Account_ID NUMBER(10),
Date_of_transfer DATE,
Transfer_Amount NUMBER(15)
);

CREATE TABLE Payee_table
(
Account_no NUMBER REFERENCES Account_master(Account_no),
Payee_Account_no NUMBER PRIMARY KEY,
Nick_nsme VARCHAR2(40)
);

CREATE SEQUENCE seq_acc_num START WITH 100000;
CREATE SEQUENCE seq_fund_id START WITH 1000;
CREATE SEQUENCE seq_ser_id START WITH 100;

