package com.acapgemini.Exception;

public class OnlineBankException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OnlineBankException(String message) {
		super(message);
	}
}
