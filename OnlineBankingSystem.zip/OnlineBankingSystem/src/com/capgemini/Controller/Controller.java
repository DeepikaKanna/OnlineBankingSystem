package com.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.acapgemini.Exception.OnlineBankException;
import com.capgemini.Service.IOnlineBankService;
import com.capgemini.Service.OnlineBankServiceImplt;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String userName;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = null;
		String operation = (String) request.getParameter("action");
		PrintWriter out = response.getWriter();
		
		System.out.println(operation);
		if(operation!=null && operation.equals("Login")){
			
			session = request.getSession(true);
			long userId =  Long.parseLong((String)request.getParameter("userID"));
			String pwd = (String)request.getParameter("pwd");
			
			IOnlineBankService service = new OnlineBankServiceImplt();
			try {
				String result = service.validateUser(userId, pwd);
				if(!result.equals("fail")){
					session.setAttribute("uname", result);
					System.out.println("\n\nreached if\n\n");
					ServletContext context = getServletContext();
					RequestDispatcher rd = context.getRequestDispatcher("/homeUser.jsp");
					rd.forward(request, response);
				}
				else{
					session.setAttribute("uname", "fail");
					System.out.println("\n\nreached else\n\n");
					ServletContext context = getServletContext();
					RequestDispatcher rd = context.getRequestDispatcher("/login.jsp");
					rd.forward(request, response);
				}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			
			
		}
		
		
	}

}
