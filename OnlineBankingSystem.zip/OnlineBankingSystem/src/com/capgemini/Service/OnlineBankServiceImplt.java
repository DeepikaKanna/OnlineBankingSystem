package com.capgemini.Service;

import java.sql.SQLException;

import com.acapgemini.Exception.OnlineBankException;
import com.capgemini.Dao.IOnlineBankDao;
import com.capgemini.Dao.OnlineBankDaoImplt;

public class OnlineBankServiceImplt implements IOnlineBankService {

	@Override
	public String validateUser(long userId, String password) throws OnlineBankException, SQLException {
		
		IOnlineBankDao dao = new OnlineBankDaoImplt();
		String result = dao.validateUser(userId, password);
		
		return result;
	}

}
