package com.capgemini.Service;

import java.sql.SQLException;

import com.acapgemini.Exception.OnlineBankException;

public interface IOnlineBankService {
	public abstract String validateUser(long userId, String pwd) throws OnlineBankException, SQLException;
}
