package com.capgemini.Dao;

public interface IQuerryMapper {
	public static final String USER_DETAILS="SELECT user_table.user_id,user_table.login_password,customer.customer_name FROM account_master,customer,user_table WHERE account_master.account_no=user_table.account_no AND customer.account_no=account_master.account_no";

}
