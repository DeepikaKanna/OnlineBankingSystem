package com.capgemini.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.acapgemini.Exception.OnlineBankException;
import com.capgemini.DBUtil.DBConnection;





public class OnlineBankDaoImplt implements IOnlineBankDao{
	
	
	@Override
	public String validateUser(long userId, String password) throws OnlineBankException, SQLException {
		String result = null;
		Connection con = DBConnection.getConnection();
		PreparedStatement st;
		int flag = 0;
		try {
			st = con.prepareStatement(IQuerryMapper.USER_DETAILS);
			ResultSet rs = st.executeQuery();
			while(rs.next()){
				long id = Long.parseLong(rs.getString(1));
				String pwd = rs.getString(2);
				if(id==userId && password.equals(pwd)){
					flag = 1;
					result=rs.getString(3);
					break;
				}
			}
			if(flag==0){
				result ="fail";
			}
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return result;
	}

}
