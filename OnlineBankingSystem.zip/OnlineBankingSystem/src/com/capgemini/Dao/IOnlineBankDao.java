package com.capgemini.Dao;

import java.sql.SQLException;

import com.acapgemini.Exception.OnlineBankException;

public interface IOnlineBankDao {
	public abstract String validateUser(long userId,String password) throws OnlineBankException, SQLException;
}
