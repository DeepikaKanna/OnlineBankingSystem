package com.capgemini.DBUtil;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.acapgemini.Exception.OnlineBankException;

public class DBConnection {

	public static Connection getConnection() throws OnlineBankException{
		InitialContext ic;

		try {
			ic = new InitialContext();
			DataSource ds = (DataSource)ic.lookup("java:/OracleDS");
			Connection con = ds.getConnection();
			return con;
		}
		catch (NamingException e) {
			throw new OnlineBankException(e.getMessage());
		} 
		catch (SQLException e) {
			throw new OnlineBankException(e.getMessage());
		}
		
	}
}
