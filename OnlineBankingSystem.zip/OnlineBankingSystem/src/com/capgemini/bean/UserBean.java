package com.capgemini.bean;

public class UserBean {

}
