package com.capgemini.onlineBanking.pi;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;
import com.capgemini.onlineBanking.service.IUserAccount;
import com.capgemini.onlineBanking.service.UserAccount;

public class Client {

	public static Scanner scan = new Scanner(System.in);
	IUserAccount inf = new UserAccount();
	
	
	//Method used to Logged in
	public String Login(){
		int count=0;
		String userName = null;
		String pwd = null;
		String result=null;
		do{
		count++;
		
		if(count<=3){
		System.out.println("Enter User Id : ");
		userName = scan.next();
		
		System.out.println("Enter Password : ");
		pwd = scan.next();
		result=inf.isValidUser(userName,pwd);
		}
		else if(count>3){
			System.out.println("Account Blocked");
			inf.blockAccount(userName,pwd);
			break;
		}
		}while(result=="false");
		
		return result; 
	}
	
	
	//Method that register users
	/*public UserAccountBean Register(){
		
		UserAccountBean user = null;
		
		String userName = null;
		String pwd = null;
		long mobile;
		long accountno;
		String email = null;
		
		System.out.println("Enter User Name: ");
		userName = scan.next();
		
		System.out.println("Email Id : ");
		email = scan.next();
		
		System.out.println("Mobile Number :");
		mobile = scan.nextLong();
		System.out.println("Account number");
		accountno=scan.nextLong();
		
		System.out.println("Enter New Password : ");
		pwd = scan.next();
	
		user = new UserAccountBean();
		
		user.setUserName(userName);
		user.setPassword(pwd);
		
		user.setUserName(userName);
		user.setPassword(pwd);
		user.setMobile(mobile);
		user.setEmail(email);
		
		return user;
	}*/
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException, onlineBankingException {
		
		Client c = new Client();
		UserAccountBean user =new UserAccountBean();
		
		int choice;
		int count = 0;
		
		do{
		
			System.out.println("1. Log In");
			System.out.println("2. Register Account");
			
			System.out.println("Enter your choice(1-2) : ");
			choice = scan.nextInt();
			
			switch(choice){
				case 1:
					//Login In
					String bool = c.Login();
					if(bool!="false"){
						System.out.println("Welcome Succuessfully Logged In....");
						System.out.println("Choose the option");
						System.out.println("1.View Mini Statement");
						System.out.println("2.View Detailed Statement");
						System.out.println("3.Update Mobile number");
						System.out.println("4.Request for cheque book");
						System.out.println("5.Track cheque book request");
						System.out.println("6.Fund Transfer");
						long account=Long.valueOf(bool);
						//System.out.println(account);
						UserAccountBean rb=new UserAccountBean();
						rb.setAccountNo(account);
						System.out.println("Enter your choice");
						int choices=scan.nextInt();
						IUserAccount iua=new UserAccount();
						switch(choices){
						case 1:String miniStatement=iua.getMiniStatement(account);
							   System.out.println("Account Number     Transaction Id             Transaction Date");
							   System.out.println("_________________________________________________");
							   System.out.println(miniStatement);
							   break;
							   
						case 3:
							choice = c.displayUpdateMenu();
							if(choice == 1){
								System.out.println("Enter New Email ID: ");
								String emailId = scan.next();
								
								if(c.updateEmail(emailId,rb.getAccountNo())){
									System.out.println("Mobile Number updated Successfully...");
								}
								else System.out.println("Mobile Number Not updated...");
							}
							else{
								System.out.println("Enter New Address: ");
								//int dummy=scan.nextInt();
								scan.nextLine();
								String address=scan.nextLine();
								
								if(c.updateAddress(address,rb.getAccountNo())){
									System.out.println("Address updated Successfully...");
								}
								else System.out.println("Address Not updated...");
							}
					
					break;
						case 6:System.out.println("Enter amount want to transfer");
						  	   int amount=scan.nextInt();
						  	   System.out.println("Enter payee Account number");
						  	   long paccount=scan.nextLong();
						  	   boolean payeeDetails=iua.validatePayee(account,paccount);
						  	   if(payeeDetails==true){
						  		   System.out.println("Enter Transaction password to continue");
						  		   String password=scan.next();
						  		   String fundTransfer=iua.transferFund(account,paccount,amount,password);
						  		   if(fundTransfer.equals("true")){
						  			   System.out.println("Fund Transfered Success");
						  		   }
						  		   else if(fundTransfer.equals("false")){
						  			   System.out.println("Fund Transfer Failed");
						  		   }
						  		   else{
						  			   System.out.println("Wrong Transaction Password");
						  		   }
						  		   
						  	   }
						  	   else{
						  		   System.out.println("Not a validate payee");
						  	   }
						}
					}
					else{
						choice = -1;
						System.out.println("Invalid UserName and Password.....");
						
					}
					break;
				case 2:
					boolean userdetails=true;
					try{//Register
					userdetails = c.Register();
					if(userdetails==false){
						System.out.println("Sucessfully Registered.....");
					}
					else{
						choice = -1;
						System.out.println("Invalid Registration Details...");
					}
					}
					catch(onlineBankingException e){
						System.out.println(e.getMessage());
					}
					
					
					break;
					
				default : System.out.println("Incorrect Choice....");
			}
		}while(choice!=1 && choice!=2);
		

	}


	private boolean Register() throws ClassNotFoundException, SQLException, IOException, onlineBankingException {
		long accId;
		long userId;
		String loginPass;
		String secQ;
		String secA;
		String transPass;
		char lockStatus;
		
		UserAccountBean useraccountbean=new UserAccountBean();
		System.out.println("Enter your Account ID: ");
		accId = scan.nextLong();
		useraccountbean.setAccountNo(accId);
		
		System.out.println("Enter your user ID: ");
		userId = scan.nextLong();
		useraccountbean.setUserid(userId);
		
		System.out.println("Enter yor login password:");
		loginPass = scan.next();
		useraccountbean.setLoginpassword(loginPass);
		
		System.out.println("What is your favourite color?");
		secQ="What is your favourite color?";
		secA=scan.next();
		useraccountbean.setSecurityQuestion(secQ);
		useraccountbean.setSecurityAnswer(secA);
		
		System.out.println("Enter your transaction password : ");
		transPass = scan.next();
		useraccountbean.setTransPassword(transPass);
		
		lockStatus='l';
		useraccountbean.setLockStatus(lockStatus);
	
	
		return inf.getRegistered(useraccountbean);

	}
	
	

	int displayUpdateMenu(){
		int choice;
		
		System.out.println("Choose any one of the option");
		System.out.println("1. Update Mobile Number");
		System.out.println("2. Update Address");
		
		choice = scan.nextInt();
		
		return choice;
		
	}
	
	
	boolean updateEmail(String emailId,long accNumber){
		
		boolean result = inf.updateEmail(emailId,accNumber);
		
		return result;
	}
	
	
	boolean updateAddress(String address,long accNumber){
		
		boolean result = inf.updateAddress(address,accNumber);
		
		return result;
	}

}
