package com.capgemini.onlineBanking.pi;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;
import com.capgemini.onlineBanking.service.IUserAccount;
import com.capgemini.onlineBanking.service.UserAccount;

public class Client {

	public static Scanner scan = new Scanner(System.in);
	IUserAccount inf = new UserAccount();
	
	
	//Method used to Logged in
	public String Login(){
		int count=0;
		String userId = null;
		String pwd = null;
		String result=null;
		do{
			count++;
			
			if(count<=3){
			
				do{
					System.out.println("Enter User Id : ");
					userId = scan.next();
					
					if(userId.equals("admin"))
						break;
					
				}while(!inf.isValidId(userId));
				
				System.out.println("Enter Password : ");
				pwd = scan.next();
				
				if(userId.equals("admin") && pwd.equals("admin")){
					result="admin";
				}
				else{
					try{
						result=inf.isValidUser(userId,pwd);
					}
					catch(onlineBankingException e){
						System.out.println(e.getMessage());
					}
				}
			}
			else if(count>3){
				System.out.println("Account Blocked");
				inf.blockAccount(userId,pwd);
				break;
			}
		}while(result=="false");
		
		return result; 
	}
	
	

	public static void main(String[] args) throws onlineBankingException, ClassNotFoundException, SQLException, IOException {
		IUserAccount inf = new UserAccount();
		Client c = new Client();
		UserAccountBean user =new UserAccountBean();
		
		int choice;
		int count = 0;
		
		do{
		
			System.out.println("1. Log In");
			System.out.println("2. Register Account");
			
			System.out.println("Enter your choice(1-2) : ");
			choice = scan.nextInt();
			
			switch(choice){
				case 1:
					//Login In
					String bool = c.Login();
					if(bool.equals("admin")){
						System.out.println("Welcome Admin....");
						System.out.println("choose the option(1-3):");
						System.out.println("1. Generate New Account");
						System.out.println("2. View Transaction of all accounts");
						int option = scan.nextInt();
						if(option==1){
							c.generateNewAccount();
						}
						else{
							c.viewTransactions();
						}
					}
					else if(bool!="false"){
						System.out.println("Welcome Succuessfully Logged In....");
						//c.displayUserMenu();
						long account=Long.valueOf(bool);
						//System.out.println(account);
						UserAccountBean rb=new UserAccountBean();
						rb.setAccountNo(account);
						//System.out.println("Enter your choice");
						//int choices=scan.nextInt();
						IUserAccount iua=new UserAccount();
						while(true){
							c.displayUserMenu();
							System.out.println("Enter your choice");
							int options=scan.nextInt();
						switch(options){
						case 1:try
						{
							String miniStatement=iua.getMiniStatement(account);
						
							   System.out.println("Account Number     Transaction Id             Transaction Date");
							   System.out.println("_____________________________________________________________________");
							   System.out.println(miniStatement);
							 
						}
						catch(onlineBankingException e)
						{
				             System.out.println(e.getMessage());
						}
						  break;
						case 2:
							try
							{
								String fromDate;
								String toDate;
								do{
									System.out.println("Enter From Date");		
									fromDate=scan.next();
								}while(!inf.isValidDate(fromDate));
								do{
									System.out.println("Enter To Date");
									toDate=scan.next();
								}while(!inf.isValidDate(toDate));
								String detailedStatement=iua.getDetailedStatement(account,fromDate,toDate);
								System.out.println("Account Number            Transaction_id            Transaction Date");
								System.out.println("_________________________________________________________________________");
								System.out.println(detailedStatement);
							}
							catch(onlineBankingException e)
							{
					             System.out.println(e.getMessage());
							}
						   break;
						case 3:
							choice = c.displayUpdateMenu();
							if(choice == 1){
								String emailId = null;
								do{
									System.out.println("Enter New Email ID: ");
									 emailId = scan.next();
								}while(!inf.isValidEmail(emailId));
								
								if(c.updateEmail(emailId,rb.getAccountNo())){
									System.out.println("Email updated Successfully...");
								}
								else System.out.println("Email Not updated...");
							}
							else{
								System.out.println("Enter New Address: ");
								//int dummy=scan.nextInt();
								scan.nextLine();
								String address=scan.nextLine();
								
								if(c.updateAddress(address,rb.getAccountNo())){
									System.out.println("Address updated Successfully...");
								}
								else System.out.println("Address Not updated...");
							}
					
					break;
						case 4:System.out.println("Check book request");
							   String checkBook=iua.raiseCheckBook(account);
							   System.out.println("Your Service Request: "+checkBook);
					break;
						case 5:
							System.out.println("Enter service id: ");
							long serviceId = scan.nextLong();
							IUserAccount service = new UserAccount();
							String description = service.getServiceDetails(serviceId,rb.getAccountNo());
							if(description.equals("Not Found")){
								System.out.println("No Service request with selected service id...");
								System.out.println("view all your service rerquest(Yes/No):");
								String ch=scan.next();
								if(ch.equals("Yes")){
									String str = service.getAllServiceDetails(rb.getAccountNo());
									if(str.equals("Not Found")){
										System.out.println("No Service request...");
									}
									else{
										System.out.println(str);
									}
								}
													
							}
							else System.out.println(description);
												
						break;
					
						case 6:
						  	   List<String> list=new ArrayList<>(20);
						  	   list=iua.getAvailablePayees(account);
						  	   for(String s:list){
						  		   System.out.println(s);
						  	   }
						  	   System.out.println("1.Do you want to add a New Payee \n2. Use existing payee ");
						  	   int option = scan.nextInt();
						  	   if(option == 1){
							  		 long pAccount = 0;
							  		   do{
								  		   System.out.println("Enter payee Account Number");
							  			   pAccount=scan.nextLong();						  	
							  		   }while(!inf.isValidAccNumber(pAccount));
						  			   
							  		   System.out.println("Enter Nick Name");
						  			   String nickName=scan.next();
						  			   
						  			   String addPayee=iua.addNewPayee(account,pAccount,nickName);
						  			   
						  			   if(addPayee.equals("true")){
						  				   System.out.println("Payee Added Successfully");
						  				   
						  				   List<String> list1=new ArrayList<>(20);
									  	   list1=iua.getAvailablePayees(account);
									  	   for(String s:list1){
									  		   System.out.println(s);
									  	   }
									  	   tranaction(account);
						  			   }
						  			   else{
						  				   System.out.println("Payee Not Added");
						  			   }
						  	   }
						  	   else{
						  		   		tranaction(account);
						  	   }
						  	   break;
						case 7:
							System.out.println("Logged out from account Thanks for using..........");
							System.exit(0);
							break;
						default:System.out.println("Invalid Choice option");
						}
					}
					}
					else{
						choice = -1;
						System.out.println("Invalid UserId and Password.....");
						
					}
					break;
				case 2:
					boolean userdetails=true;
					try{//Register
					userdetails = c.Register();
					if(userdetails==false){
						System.out.println("Sucessfully Registered.....");
						choice=-1;
					}
					else{
						choice = -1;
						System.out.println("Invalid Registration Details...");
					}
					}
					catch(onlineBankingException e){
						System.out.println(e.getMessage());
					}
					
					
					break;
					
				default : System.out.println("Incorrect Choice....");
			}
			
		}while(choice!=1 && choice!=2);
		

	}


	private boolean Register() throws ClassNotFoundException, SQLException, IOException, onlineBankingException {
		long accId;
		long userId;
		String loginPass;
		String secQ;
		String secA;
		String transPass;
		String lockStatus;
		
		UserAccountBean useraccountbean=new UserAccountBean();
		
		do{
			System.out.println("Enter your Account ID: ");
			accId = scan.nextLong();			
		}while(!inf.isValidAccNumber(accId));
		
		useraccountbean.setAccountNo(accId);
		String id = null;
		do{
			System.out.println("Enter your user ID: ");
			userId = scan.nextLong();
			id = Long.toString(userId);
		}while(!inf.isValidId(id));
		
		useraccountbean.setUserid(userId);
		
		System.out.println("Enter yor login password:");
		loginPass = scan.next();
		useraccountbean.setLoginpassword(loginPass);
		
		System.out.println("What is your favourite color?");
		secQ="What is your favourite color?";
		secA=scan.next();
		
		useraccountbean.setSecurityQuestion(secQ);
		useraccountbean.setSecurityAnswer(secA);
		
		System.out.println("Enter your transaction password : ");
		transPass = scan.next();
		useraccountbean.setTransPassword(transPass);
		
		lockStatus="L";
		useraccountbean.setLockStatus(lockStatus);
	
	
		return inf.getRegistered(useraccountbean);

	}
	int displayUpdateMenu(){
		int choice;
		
		System.out.println("Choose any one of the option");
		System.out.println("1. Update Email Address");
		System.out.println("2. Update Address");
		
		choice = scan.nextInt();
		
		return choice;
		
	}
	
	
	boolean updateEmail(String emailId,long accNumber){
		
		UserAccountBean useraccountbean=new UserAccountBean();
		useraccountbean.setEmail(emailId);
		useraccountbean.setAccountNo(accNumber);
		
		boolean result = inf.updateEmail(useraccountbean);
		
		return result;
	}
	
	
	boolean updateAddress(String address,long accNumber){
		UserAccountBean useraccountbean=new UserAccountBean();
		useraccountbean.setAddress(address);
		useraccountbean.setAccountNo(accNumber);
		
		boolean result = inf.updateAddress(useraccountbean);
		
		return result;
	}
	static void tranaction(long account) throws onlineBankingException{
		IUserAccount iua=new UserAccount();
		 long paccount = 0;
		do{
		   System.out.println("Enter payee Account number");
	  	   paccount=scan.nextLong();
		}while(!iua.isValidAccNumber(paccount));
	  	
		int amount;
	  	do{
	  	   System.out.println("Enter amount want to transfer");
	  	   amount=scan.nextInt();
	  	 }while(amount>1000000);
	  	 try{
	  	   
	  		 boolean payeeDetails=iua.validatePayee(account,paccount); 	 
	  	 
			  	if(payeeDetails==true){
			  		   System.out.println("Enter Transaction password to continue");
			  		   String password=scan.next();
			  		   String fundTransfer=iua.transferFund(account,paccount,amount,password);
			  		   if(fundTransfer.equals("true")){
			  			   System.out.println("Fund Transfered Success");
			  		   }
			  		   else if(fundTransfer.equals("false")){
			  			   System.out.println("Fund Transfer Failed");
			  		   }
			  		   else{
			  			   System.out.println("Wrong Transaction Password");
			  		   }
			  		   
			  	   }
			  	   else{
			  		   System.out.println("Not a validate payee");
			  	   }
			
	  	 }
	 catch(Exception e)
 	  {
 		  throw new onlineBankingException("Invalid Transaction");
 	  }

	}
	
	String generateNewAccount(){
		IUserAccount inf = new UserAccount();
		String emailId = null;
		String accName = null;
		String accType = null;
		long balance = 0;
		String panCard = null;
		
		scan.nextLine();
		do{
			System.out.println("Enter Account Holder Name:");
			accName = scan.nextLine();
		}while(!inf.isValidName(accName));
		
		System.out.println("Enter address:");
		String address = scan.nextLine();
		//scan.nextLine();
		
		do{
			System.out.println("Enter Email Id:");
			emailId= scan.next();
		}while(!inf.isValidEmail(emailId));
		do{
			System.out.println("Enter account type: ");
			accType=scan.next();
		}while(!inf.isValidAccountType(accType));
		
		boolean isValid = false;
		do{
			try{
				System.out.println("Enter Opening Balance:");
				balance = scan.nextLong();
				isValid = true;
				if(balance<0)
					isValid=false;
			}
			catch(InputMismatchException e){
				scan.nextLine();
			}
		}while(!isValid);
		do{
			System.out.println("Enter PanCard Number:");
			panCard = scan.next();
		}while(!inf.isValidPanCard(panCard));
		
		UserAccountBean bean = new UserAccountBean();
		bean.setAccName(accName);
		bean.setAddress(address);
		bean.setEmail(emailId);
		bean.setAccType(accType);
		bean.setBalance(balance);
		bean.setPanCard(panCard);
		
		IUserAccount service = new UserAccount();
		
		String result = service.generateNewAccount(bean);
		if(result.equals("success")){
			System.out.println("Account Created Successfully....");
		}
		else System.out.println("Failed to Create Account");
		
		return result;
}

	void viewTransactions(){
		System.out.println("Choose your option to view Transactions");
		System.out.println("1.View Transactions on Yearly basis");
		System.out.println("2.View Transactions on Monthly basis");
		System.out.println("3.View Transactions on Daily basis");
		int choice=scan.nextInt();
		IUserAccount iua=new UserAccount();
		
		switch(choice){
			case 1:int year = Calendar.getInstance().get(Calendar.YEAR);
			   //System.out.println(year);
			   String transactionYear=iua.getYearlyTransaction(year);
			   System.out.println("TransactionId        AccountNo               TransactionDate");
			   System.out.println("\n____________________________________________________________________________________\n");
			   System.out.println(transactionYear);
			   break;
			case 2:int month = Calendar.getInstance().get(Calendar.MONTH);
		  // System.out.println(month);
		   String transactionMonth=iua.getMonthlyTransaction(month);
		   System.out.println("TransactionId        AccountNo               TransactionDate");
		   System.out.println("\n____________________________________________________________________________________\n");
		   System.out.println(transactionMonth);
		   break;
			case 3:int date = Calendar.getInstance().get(Calendar.DATE);
		   //System.out.println(date);
			String transactionDate=iua.getDateTransaction(date);
		   System.out.println("TransactionId        AccountNo               TransactionDate");
		   System.out.println("\n____________________________________________________________________________________\n");
		   System.out.println(transactionDate);
		   break;
	    
		}
		
	}
	void displayUserMenu(){
		System.out.println("Choose the option");
		System.out.println("1.View Mini Statement");
		System.out.println("2.View Detailed Statement");
		System.out.println("3.Update Mobile number");
		System.out.println("4.Request for cheque book");
		System.out.println("5.Track cheque book request");
		System.out.println("6.Fund Transfer");
		System.out.println("7.Exit");
	}
	
}
