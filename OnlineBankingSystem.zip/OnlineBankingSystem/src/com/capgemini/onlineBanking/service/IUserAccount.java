package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public interface IUserAccount {
	String isValidUser(String userName, String pwd) throws onlineBankingException;

	String registerUser(UserAccountBean useraccountbean) throws onlineBankingException;

	String getMiniStatement(long account) throws onlineBankingException;

	boolean validatePayee(long account, long paccount) throws onlineBankingException;

	String transferFund(long account, long paccount, int amount,String password) throws onlineBankingException;

	void blockAccount(String userName, String pwd) throws onlineBankingException;
	
	String getDetailedStatement(long account, String fromDate, String toDate) throws onlineBankingException;
	
	String updateEmail(UserAccountBean useraccountbean) throws onlineBankingException;

	String updateAddress(UserAccountBean useraccountbean) throws onlineBankingException;
	
	String raiseCheckBook(long account) throws onlineBankingException;

	List<String> getAvailablePayees(long account) throws onlineBankingException;

	String addNewPayee(long account, long pAccount,String nickName) throws onlineBankingException;
	
	String getServiceDetails(long serviceId,long accNumber)throws onlineBankingException;
	
	String getAllServiceDetails(long accNumber) throws onlineBankingException;
	
	String generateNewAccount(UserAccountBean bean) throws onlineBankingException;

	String getYearlyTransaction(int year) throws onlineBankingException;

	String getMonthlyTransaction(int month) throws onlineBankingException;

	String getDateTransaction(int date) throws onlineBankingException;
	
	boolean isValidId(String id);
	
	boolean isValidDate(String date);
	
	boolean isValidEmail(String email);

	boolean isValidAccNumber(long accNumber);
	
	boolean isValidName(String name);
	
	boolean isValidPanCard(String panCard);
	
	boolean isValidAccountType(String type);
}
