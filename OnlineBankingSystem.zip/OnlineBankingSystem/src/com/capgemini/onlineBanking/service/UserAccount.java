package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.dao.IUserLogin;
import com.capgemini.onlineBanking.dao.UserLoginDB;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserAccount implements IUserAccount{

	@Override
	public String isValidUser(String userName, String pwd) {
		
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.LoginValidation(userName,pwd);
		
		return result;
	}

	@Override
	public boolean getRegistered(UserAccountBean useraccountbean) throws onlineBankingException {
		boolean result;
		IUserLogin il=new UserLoginDB();
		result=il.getRegistered(useraccountbean);
		return false;
	}

	@Override
	public String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException {
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.getMiniStatement(account);
		return result;
	}

	@Override
	public boolean validatePayee(long account, long paccount) {
		boolean pdetails;
		IUserLogin il=new UserLoginDB();
		pdetails=il.validatePayee(account,paccount);
		return pdetails;
	}

	@Override
	public String transferFund(long account, long paccount, int amount,String password) {
		String transferFund;
		IUserLogin il=new UserLoginDB();
		transferFund=il.transferFunds(account,paccount,amount,password);
		return transferFund;
	}

	@Override
	public void blockAccount(String userName, String pwd) {
		IUserLogin il=new UserLoginDB();
		il.blockAccount(userName,pwd);
		
	}
	
	
	@Override
	public boolean updateAddress(String address,long accNumber) {
		IUserLogin l = new UserLoginDB();
		
		boolean bool = l.updateAddress(address,accNumber);
		
		return bool;
	}

	@Override
	public boolean updateEmail(String emailId,long accNumber) {
		IUserLogin l = new UserLoginDB();
		
		boolean bool = l.updateEmail(emailId,accNumber);
		
		return bool;
	}
	
	/*
	String getServiceDetails(long accountNumber){
		IUserAccount service = new UserAccount();
		String desc = service
	}*/

}
