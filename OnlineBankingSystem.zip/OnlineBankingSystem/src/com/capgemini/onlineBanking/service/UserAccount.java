package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.dao.IUserLogin;
import com.capgemini.onlineBanking.dao.UserLoginDB;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserAccount implements IUserAccount{

	@Override
	public String isValidUser(String userName, String pwd) throws onlineBankingException{
		
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.LoginValidation(userName,pwd);
		
		return result;
	}

	@Override
	public String registerUser(UserAccountBean useraccountbean) throws onlineBankingException {
		String result =null;
		
		IUserLogin il=new UserLoginDB();
		
		result = il.registerUser(useraccountbean);
		
		return result;
	}

	@Override
	public String getMiniStatement(long account) throws onlineBankingException{
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.getMiniStatement(account);
		return result;
	}

	@Override
	public boolean validatePayee(long account, long paccount) throws onlineBankingException{
		boolean pdetails;
		IUserLogin il=new UserLoginDB();
		pdetails=il.validatePayee(account,paccount);
		return pdetails;
	}

	@Override
	public String transferFund(long account, long paccount, int amount,String password) throws onlineBankingException {
		String transferFund;
		IUserLogin il=new UserLoginDB();
		transferFund=il.transferFunds(account,paccount,amount,password);
		return transferFund;
	}

	@Override
	public void blockAccount(String userName, String pwd) throws onlineBankingException {
		IUserLogin il=new UserLoginDB();
		il.blockAccount(userName,pwd);
		
	}
	@Override
	public String getDetailedStatement(long account, String fromDate, String toDate) throws onlineBankingException {
		String detailedStatement;
		IUserLogin il=new UserLoginDB();
		detailedStatement=il.getDetailedStatement(account,fromDate,toDate);
		
		
		return detailedStatement;
	}
	@Override
	public String updateEmail(UserAccountBean useraccountbean) throws onlineBankingException{
		String updateStatus;
		IUserLogin il=new UserLoginDB();
		updateStatus=il.updateEmail(useraccountbean);
		return updateStatus;
	}

	@Override
	public String updateAddress(UserAccountBean useraccountbean) throws onlineBankingException{
		String updateStatus;
		IUserLogin il=new UserLoginDB();
		updateStatus=il.updateAddress(useraccountbean);
		return updateStatus;
	}
	@Override
	public String raiseCheckBook(long account) throws onlineBankingException {
		String checkbookRequest;
		IUserLogin il=new UserLoginDB();
		checkbookRequest=il.raiseCheckBookRequest(account);
		return checkbookRequest;
	}

	@Override
	public List<String> getAvailablePayees(long account) throws onlineBankingException{
		List<String> payees=new ArrayList<>(20);
		IUserLogin il=new UserLoginDB();
		payees=il.getAvailablePayees(account);
		return payees;
	}

	@Override
	public String addNewPayee(long account, long pAccount,String nickName) throws onlineBankingException{
		String addPayee;
		IUserLogin il=new UserLoginDB();
		addPayee=il.addNewPayee(account,pAccount,nickName);
		return addPayee;
	}
	
	public String getServiceDetails(long serviceId,long accNumber) throws onlineBankingException{
		IUserLogin dao = new UserLoginDB();
			
		String desc = dao.getServiceDetails(serviceId,accNumber);
		return desc;
	}
		
	public String getAllServiceDetails(long accNumber) throws onlineBankingException{
		IUserLogin dao = new UserLoginDB();
			
		String desc = dao.getAllServiceDetails(accNumber);
		return desc;
	}
	
	@Override
	public String generateNewAccount(UserAccountBean bean) throws onlineBankingException{
		IUserLogin dao = new UserLoginDB();
			
		String result = dao.generateNewAccount(bean);
			
		return result;
	}

	@Override
	public String getYearlyTransaction(int year) throws onlineBankingException{
		String transactions;
		IUserLogin dao = new UserLoginDB();
		transactions=dao.getYearTransaction(year);
		return transactions;
	}

	@Override
	public String getMonthlyTransaction(int month) throws onlineBankingException{
		String transactions;
		IUserLogin dao = new UserLoginDB();
		transactions=dao.generateMonthTransaction(month);
		return transactions;
	}

	@Override
	public String getDateTransaction(int date) throws onlineBankingException{
		String transactions;
		IUserLogin dao = new UserLoginDB();
		transactions=dao.generateDateTransaction(date);
		return transactions;
	}

	@Override
	public boolean isValidId(String userId) {
		boolean isValid;
		
		//name should have first letter as UpperCase with minimum 3 characters and maximum 50
		//Pattern pattern = Pattern.compile("^[A-Z][a-zA-Z]{2,50}");
		Pattern pattern = Pattern.compile("^[1-9][0-9]{4}");
		Matcher m = pattern.matcher(userId);
		
		isValid = m.find();
		
		return isValid;
	}

	@Override
	public boolean isValidDate(String date) {
		boolean isValid = false;
		
		String[] months31 = {"JAN","MAR","MAY","JUL","AUG","OCT","DEC"};
		String[] months30 = {"APR","JUN","SEP","NOV"};
		String[] splitDate = date.split("\\-");
		int d=0;
		try{
			d = Integer.parseInt(splitDate[0]);
		}
		catch(NumberFormatException e){
			return false;
		}
		
		if(splitDate.length!=3)
			isValid = false;
		
		else if(splitDate[1].equals("FEB") && d>0 && d<30)
			isValid = true;
		
		else if(isValid == false){			
			if(d > 0 && d < 32){
				 for (String m : months31) {
				        if (m.equals(splitDate[1])) {
				           isValid = true;
				           break;
				        }
				 }
				 if(isValid==false){
					 for (String m : months30) {
					        if (m.equals(splitDate[1])) {
					        	if(d < 31){
					        		isValid = true;
					        	}
				        		break;
					        }
					 }
				 }
			}
			if(isValid==true){
				int year = Integer.parseInt(splitDate[2]);
				if(year<1900 || year>2018){
					isValid = false;
				}
			}
		}

		return isValid;
	}

	@Override
	public boolean isValidEmail(String email) {
		boolean isValid = false;
		Pattern pattern = Pattern.compile("^[a-z A-Z]+@[a-z]+\\.[a-z]{3}");
		Matcher m = pattern.matcher(email);
		
		isValid = m.find();
		
		return isValid;
	}

	@Override
	public boolean isValidAccNumber(long accNumber) {
		String accNo = Long.toString(accNumber);
		boolean isValid = false;
		
		Pattern pattern = Pattern.compile("^[1-9][0-9]{9}");
		Matcher m = pattern.matcher(accNo);
		
		isValid = m.find();
		
		
		return isValid;
	}

	@Override
	public boolean isValidName(String name) {
		boolean isValid = false;
		
		Pattern pattern = Pattern.compile("^[A-Z][a-zA-Z]{2,50}");
		Matcher m = pattern.matcher(name);
		
		isValid = m.find();
		
		
		return isValid;
	}

	@Override
	public boolean isValidPanCard(String panCard) {
		boolean isValid = false;
		
		Pattern pattern = Pattern.compile("^[A-Z]{5}[0-9]{4}[A-Z]{1}");
		Matcher m = pattern.matcher(panCard);
		
		isValid = m.find();
		
		
		return isValid;
	}

	@Override
	public boolean isValidAccountType(String type) {
		boolean isValid = false;
		
		if(type.equalsIgnoreCase("savings") || type.equalsIgnoreCase("Current"))
			isValid = true;
		return isValid;
	}
	
	

}
