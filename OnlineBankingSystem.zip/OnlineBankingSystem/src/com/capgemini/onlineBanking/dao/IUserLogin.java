package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public interface IUserLogin {

	String LoginValidation(String userName, String pwd) throws onlineBankingException;

	String registerUser(UserAccountBean useraccountbean) throws onlineBankingException;

	String getMiniStatement(long account) throws onlineBankingException;

	boolean validatePayee(long account, long paccount) throws onlineBankingException;

	String transferFunds(long account, long paccount, int amount,String password) throws onlineBankingException;

	void blockAccount(String userName, String pwd) throws onlineBankingException;
	
	String getDetailedStatement(long account, String fromDate, String toDate) throws onlineBankingException;
	
	String updateEmail(UserAccountBean useraccountbean) throws onlineBankingException;

	String updateAddress(UserAccountBean useraccountbean) throws onlineBankingException;
	
	String raiseCheckBookRequest(long account) throws onlineBankingException;

	List<String> getAvailablePayees(long account) throws onlineBankingException;

	String addNewPayee(long account, long pAccount,String nickName)throws onlineBankingException;
	
	String getAllServiceDetails(long accNumber) throws onlineBankingException;
	
	String getServiceDetails(long serviceId,long accNumber) throws onlineBankingException;
	
	String generateNewAccount(UserAccountBean bean) throws onlineBankingException;

	String getYearTransaction(int year) throws onlineBankingException;
	
	String generateMonthTransaction(int month) throws onlineBankingException;

	String generateDateTransaction(int date) throws onlineBankingException;
}
