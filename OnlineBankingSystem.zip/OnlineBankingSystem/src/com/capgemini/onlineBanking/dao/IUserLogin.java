package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public interface IUserLogin {

	String LoginValidation(String userName, String pwd) throws onlineBankingException;

	boolean getRegistered(UserAccountBean useraccountbean) throws onlineBankingException;

	String getMiniStatement(long account) throws onlineBankingException;

	boolean validatePayee(long account, long paccount) throws onlineBankingException;

	String transferFunds(long account, long paccount, int amount,String password) throws onlineBankingException;

	void blockAccount(String userName, String pwd);
	String getDetailedStatement(long account, String fromDate, String toDate) throws onlineBankingException;
	boolean updateEmail(UserAccountBean useraccountbean);

	boolean updateAddress(UserAccountBean useraccountbean);
	String raiseCheckBookRequest(long account);

	List<String> getAvailablePayees(long account);

	String addNewPayee(long account, long pAccount,String nickName);
	
	String getAllServiceDetails(long accNumber);
	
	String getServiceDetails(long serviceId,long accNumber);
	
	String generateNewAccount(UserAccountBean bean);

	String getYearTransaction(int year);
	
	String generateMonthTransaction(int month);

	String generateDateTransaction(int date);
}
