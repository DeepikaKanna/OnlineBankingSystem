package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.onlineBanking.Util.RechargeDBConnection;
import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserLoginDB implements IUserLogin {

	@Override
	public String LoginValidation(String userName, String pwd) {
		String password=null;
		String result = "false";
		UserAccountBean rb=new UserAccountBean();
		long accountno;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select password,accountno from bankusers where username='"+userName+"'"); 
		/*
		 * ResultSet rs = stmt.executeQuery(IQuerryMapper.SELECT_USERINFO);
		 */
		if(rs!=null){
			while(rs.next()){
				password=rs.getString(1);
				accountno=rs.getLong(2);
				//System.out.println(password);
				//System.out.println(pwd);
				if(password.equals(pwd)){
					//rb.setAccNumber(accountno);
					result=String.valueOf(accountno);
					//System.out.println(result);
				}
				else{
					result="false";
					//System.out.println(result);
				}
				//sb.append(planname+"      "+Integer.toString(amount)+"\n");
				//System.out.println(details);
				
			}
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ 
			//msg=e.getMessage();
		}

		return result;
	}

	@Override
	public boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws onlineBankingException {
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		String s1="insert into bankusers values(?,?,?,?,?)";
		PreparedStatement s=con.prepareStatement(s1);
		//String s2="select rec_seq.nextval from dual";
		java.sql.Statement sw=con.createStatement();
		//ResultSet r1=sw.executeQuery(s2);
		//s.executeUpdate();
		s=con.prepareStatement(s1);
		//s.setInt(1,val);
		s.setString(1,userName);
		s.setString(2,pwd);
		s.setLong(3, mobile);
		s.setLong(4, accountno);
		//s.setString(4,status);
		s.setString(5,email);
		//s.setInt(6,amount);
		int status=s.executeUpdate();
		if(status>0){
			System.out.println("Values inserted successfully");
		}
		else{
			throw new onlineBankingException("Values are not inserted");
		}
		}
		catch(Exception e){
			throw new onlineBankingException("Values Not Inserted");
		}
		return false;
	}

	@Override
	public String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException {
		String trans_details=null;
		Long acc_no;
		StringBuilder sb=new StringBuilder();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select accountno,date_of_transaction from usertransaction where accountno='"+account+"' and rownum<=5"); 
		
		if(rs!=null){
			while(rs.next()){
				//account=rs.getLong(1);
				trans_details=rs.getString(2);
				acc_no=rs.getLong(1);
				sb.append(acc_no+"                   "+trans_details+"\n");
			}
		}
		con.close();  
		  
	}catch(Exception e){ 
		//msg=e.getMessage();
	}
		// TODO Auto-generated method stub
		return sb.toString();
	}

	@Override
	public boolean updateAddress(String address,long accNumber) {
		boolean result = false;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="update bankusers set address = '"+ address + "' where accountno = " + accNumber;
			PreparedStatement s=con.prepareStatement(s1);
			
			int status=s.executeUpdate();
			if(status>0)
				result = true;
			else result = false;
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;
		
	}

	@Override
	public boolean updateMobile(long mobile,long accNumber) {
		boolean result = false;
	
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="update bankusers set mobile = "+ mobile + "where accountno = " + accNumber;
			PreparedStatement s=con.prepareStatement(s1);
			
			int status=s.executeUpdate();
			if(status>0)
				result = true;
			else result = false;
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			
		}
		return result;
	}

}

