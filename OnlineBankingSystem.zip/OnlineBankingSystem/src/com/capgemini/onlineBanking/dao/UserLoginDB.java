package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.management.openmbean.OpenDataException;

import oracle.net.aso.l;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.onlineBanking.Util.RechargeDBConnection;
import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserLoginDB implements IUserLogin {
	Logger logger=Logger.getRootLogger();
	public UserLoginDB()
	{
	PropertyConfigurator.configure("resources/log4j.properties");
	
	}
	
	//------------------------ 1. Online Banking System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	LoginValidation(String userName, String pwd)
		 - Input Parameters	:	
		 - Return Type		:	
		 - Throws			:  	
		 - Author			:	
		 - Creation Date	:	
		 - Description		:	
		 ********************************************************************************************************/


	@Override
	public String LoginValidation(String userName, String pwd) throws onlineBankingException {
		String password=null;
		String result = "false";
		String status=null;
		long userId=0;
		long accountno;
		
		UserAccountBean rb=new UserAccountBean();
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			logger.info("Login - Connection Established");
			
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			logger.info("Login - Statement Created Successfully");
			  
			//step4 execute query  
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.validateUser);
			pmstmt.setString(1, userName);
			
			ResultSet rs=pmstmt.executeQuery();
			logger.info("Login - Statement Executed Successfully");
			
			if(rs!=null){
				
				while(rs.next()){
					password=rs.getString(2);
					accountno=rs.getLong(1);
					status=rs.getString(3);
					
					if(password.equals(pwd)&&status.equals("U")){
						result=String.valueOf(accountno);
						logger.info("Login - Data Retrieved Successfully");
					}
					else if(accountno==0){
						result="false";
						logger.warn("Login - No Data Found");
						throw new onlineBankingException("The username/password is invalid.......");
					}
				}
			}
			
			//step5 close the connection object  
			con.close();  
			  
		}
		catch(Exception e){ 
			logger.error("Login- Failed to login-"+e.getMessage());
			throw new onlineBankingException("Failed to get Details...Invalid userId/password....");
		}

		return result;
	}
	
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	registerUser(UserAccountBean useraccountbean)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	
	@Override
	public String registerUser(UserAccountBean useraccountbean) throws onlineBankingException {
		String result = null;
		try{
				Class.forName("oracle.jdbc.driver.OracleDriver");   
				//step2 create  the connection object  
				Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
				logger.info("Register - Connection Established");
				PreparedStatement s=con.prepareStatement(IQueryMapper.registerUser);
				
				s.setLong(1,useraccountbean.getAccountNo());
				s.setLong(2,useraccountbean.getUserid());
				s.setString(3, useraccountbean.getLoginpassword());
				s.setString(4, useraccountbean.getSecurityQuestion());
			    s.setString(5,useraccountbean.getSecurityAnswer());
				s.setString(6,useraccountbean.getTransPassword());
				s.setString(7, useraccountbean.getLockStatus());
				
				int rows = s.executeUpdate();
				logger.info("Register - Statement Executed successfully");
					
				if(rows > 0){
					result = "success";
					logger.info("Register - Data Retrieved Successfully");
				}
				else{
					result= "fail";
					logger.warn("Register - Unable to Resgister the User");
					throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
				}
		}
		catch(Exception e){
			logger.error("Registration - Failed to register User - "+e.getMessage());
			throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
		}
		
		return result;
	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getMiniStatement(long account)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/



	@Override
	public String getMiniStatement(long account) throws onlineBankingException {
		String trans_details=null;
		long acc_no = 0;
		long trans_id=0;
		int count=0;
		StringBuilder sb=new StringBuilder();
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			logger.info("MiniStatement - Connection Established Successfully");
			Statement stmt=con.createStatement();  
			
			ResultSet rs=stmt.executeQuery("select count(*) from transactions where account_no='"+account+"'");
			logger.info("Ministatement - Statement Executed successfully");
			if(rs!=null){
				while(rs.next()){
					count=rs.getInt(1);
					logger.info("Ministatement - Data Retrieved successfully");
				}
			}
			else{
				logger.warn("Ministatement - No Transactons");
			}
			if(count==0){
				throw new onlineBankingException("No transactions available");
			}
			else{ 
				//step4 execute query  
				PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.miniStatement);
				pmstmt.setLong(1, account);
				rs=pmstmt.executeQuery();
				logger.info("Ministatement- Statement Executed successfully");
				if(rs!=null){
					while(rs.next()){
						//account=rs.getLong(1);
						trans_details=rs.getString(3);
						//System.out.println(trans_details);
						acc_no=rs.getLong(1);
						trans_id=rs.getLong(2);
						
						sb.append(acc_no+"                   "+trans_id+"                 "+trans_details+"\n");
					}
				}
			}
		  
		}
		catch(onlineBankingException e){ 
			logger.error("Ministatement-"+e.getMessage());
			throw new onlineBankingException("You haven't made any transactions");
		}
		catch(Exception e){
			logger.error("Ministatement-"+e.getMessage());
			throw new onlineBankingException("Failed in database Connectivity");
		}
		
		return sb.toString();
	}

	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	validatePayee(long account, long paccount)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	
	@Override
	public boolean validatePayee(long account, long paccount) throws onlineBankingException {
		long payeraccount;
		int i=0;
		long paccounts[]=new long[100];
		boolean validatePayee=false;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			logger.info("ValidatePayee - Connection Established Successfully");
			//step3 create the statement object  
			
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.validatePayee);
			pmstmt.setLong(1, account);
			
			//step4 execute query  
			ResultSet rs=pmstmt.executeQuery(); 
			logger.info("validatePayee- statement Executed successfully");
			if(rs!=null){
				while(rs.next()){
					payeraccount=rs.getLong(1);
					paccounts[i++]=payeraccount;
				}
			}
			for(i=0;i<paccounts.length;i++){
				if(paccounts[i]==paccount){
					validatePayee=true;
				}
			}
			
			//step5 close the connection object  
			con.close();  
			  
			}
		catch(Exception e){ 
				logger.error("validatePayee - "+e.getMessage());
				throw new onlineBankingException("No account found to validate");
			}
		return validatePayee;
	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	transferFunds(long account, long paccount, int amount,String password
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/


	@Override
	public String transferFunds(long account, long paccount, int amount,String password) throws onlineBankingException {
		long userBalance=0;
		long payeeBalance=0;
		String pwd=null;
		String fundTransfer="false";
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			 logger.info("transferFunds -  Connection Established Successfully");
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.validateTransPassword);
			pmstmt.setLong(1,account);
			
			ResultSet resultset=pmstmt.executeQuery();
			 logger.info("transferFunds -  Statement Executed Successfully");
			if(resultset!=null){
				while(resultset.next()){
					pwd=resultset.getString(1);
				}
			}
			if(password.equals(pwd)){
			
			pmstmt=con.prepareStatement(IQueryMapper.userBalance);
			pmstmt.setLong(1, account);
			
			ResultSet rs=pmstmt.executeQuery(); 
			 logger.info("transferFunds -  Statement Executed Successfully");
			if(rs!=null){
				while(rs.next()){
					userBalance=rs.getLong(1);
				}
			}
			
			pmstmt=con.prepareStatement(IQueryMapper.payeeBalance);
			pmstmt.setLong(1, paccount);
			
			ResultSet rs1=pmstmt.executeQuery(); 
			
			if(rs1!=null){
				while(rs1.next()){
					payeeBalance=rs1.getLong(1);
					 logger.info("transferFunds -  Data Retrieved Successfully");
				}
			}
			
			userBalance=userBalance-amount;
			payeeBalance=payeeBalance+amount;
			
			pmstmt=con.prepareStatement(IQueryMapper.updateUserBalance);
			pmstmt.setLong(1, userBalance);
			pmstmt.setLong(2, account);
			
			int userresult=pmstmt.executeUpdate();
			
			pmstmt=con.prepareStatement(IQueryMapper.updatePayeeBalance);
			pmstmt.setLong(1, payeeBalance);
			pmstmt.setLong(2, paccount);
			
			int payeeresult=pmstmt.executeUpdate();
			
			if(userresult>0&&payeeresult>0){
				long trans_id=0;
				String trans_seq_id=IQueryMapper.transaction_id;
				ResultSet resultSet=stmt.executeQuery(trans_seq_id);
				logger.info("transferFunds -  Statement Executed Successfully");
				if(resultSet!=null){
					while(resultSet.next()){
						trans_id=resultSet.getLong(1);
						 logger.info("transferFunds -  Data Retrieved Successfully");
					}
				}
				pmstmt=con.prepareStatement(IQueryMapper.transaction_Details);
				pmstmt.setLong(1, trans_id);
				pmstmt.setString(2, "Online Transaction");
				pmstmt.setString(3, "N");
				pmstmt.setLong(4, amount);
				pmstmt.setLong(5, account);
				
				int records=pmstmt.executeUpdate();
				 logger.info("transferFunds -  Statement Executed Successfully");
				
				if(records>0){
					fundTransfer="true";
					 logger.info("transferFunds -  Data retrieved Successfully");
				}
				else{
					logger.warn("transferFunds - Failed to retrieve data ");
					fundTransfer="false";
				}
				
			}
			else{
				logger.warn("transferFunds - Transfer funds Failed");
				fundTransfer="false";
			}
		}
			else{
				logger.warn("transferFunds - Wrong password ");
				fundTransfer="Wrong Transaction Password";
			}
			con.close();  
		}
		catch(Exception e){
			logger.error("transferFunds - "+e.getMessage());
			throw new  onlineBankingException("Transaction failed");
		}
		return fundTransfer;
	}

	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	void blockAccount(String userName, String pwd)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 - @throws          :   onlineBankingException 
			 ********************************************************************************************************/

	
	
	
	@Override
	public void blockAccount(String userName, String pwd) throws onlineBankingException {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			 logger.info("block Account - Connection Established Successfully");
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			logger.info("block Account - Statement Created Successfully");
			//step4 execute query  
			
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.blockAccount);
			pmstmt.setString(1,userName);
			int rs=pmstmt.executeUpdate();
			logger.info("block Account - Statement Executed Successfully");
			if(rs>0){
				logger.info("block Account - Account Blocked Successfully");
				System.out.println("Account Blocked");
			}
			else{
				logger.warn("block Account - Failed to block user - Invalid userId");
				System.out.println("Failed to recognize user_id");
			}
			//step5 close the connection object  
			con.close();  
			  
			}
			catch(Exception e){ 
				logger.error("block Account - "+e.getMessage());
		       throw new onlineBankingException("Failed to block user account..."); 
			}
		
	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getDetailedStatement(long account, String fromDate, String toDate)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	
	@Override
	public String getDetailedStatement(long account, String fromDate, String toDate) throws onlineBankingException {
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			 logger.info("getDetailedstatement - Connection Established Successfully"); 
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select count(*) from transactions where account_no='"+account+"'");
			 logger.info("getDetailedstatement - Statement Executed Successfully"); 
			int count = 0;
			if(rs!=null){
				while(rs.next()){
					 logger.info("getDetailedstatement - Data Retrieved Successfully"); 
					count=rs.getInt(1);
				}
			}
			if(count==0){
				throw new onlineBankingException("No transactions available");
			}
			else{
				PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.detailedStatement);
				pmstmt.setLong(1, account);
				pmstmt.setString(2, fromDate);
				pmstmt.setString(3, toDate);
				
				rs=pmstmt.executeQuery();
			
				if(rs!=null){
					while(rs.next()){
						 logger.info("getDetailedstatement - Data Retrieved Successfully"); 
						sb.append(rs.getString(1)+"                    "+rs.getString(2)+"                  "+rs.getString(3)+"\n");
					}
				}
			}
			
			//step5 close the connection object  
			
			  
		}
		catch(onlineBankingException e){ 
			 logger.error("getDetailedstatement - "+e.getMessage()); 
			throw new  onlineBankingException("You haven't made any transactions between these two dates");//msg=e.getMessage();
		}
		catch(Exception e)
		{
			 logger.error("getDetailedstatement - "+e.getMessage()); 
			throw new onlineBankingException("Failed in database Connectivity");
		}
		return sb.toString();

	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	updateEmail(UserAccountBean useraccountbean)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	@Override
	public String updateEmail(UserAccountBean useraccountbean) throws onlineBankingException {
		String result = "fail";
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			
			Connection con=RechargeDBConnection.getConnection();
			logger.info("update Email - Connection Established successfully");
			System.out.println(useraccountbean.getAccountNo());
			
			long acc=useraccountbean.getAccountNo();
			
			PreparedStatement s=con.prepareStatement(IQueryMapper.updateEmail);
			s.setString(1, useraccountbean.getEmail());
			s.setLong(2, useraccountbean.getAccountNo());
			
			int status=s.executeUpdate();
			logger.info("update Email - Statement Executed successfully");
			if(status>0){
				logger.info("update Email - Data Retrieved successfully");
				result = "success";
			}
			else {
				logger.warn("update Email - Fail to retrieve data");
				result = "fail";
				}
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			logger.error("Update email - "+e.getMessage());
			throw new onlineBankingException("Unable to Update Password");
		}
		return result;

	}

	//------------------------ 1. Online Banking System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	updateAddress(UserAccountBean useraccountbean)
	 - Input Parameters	:	
	 - Return Type		:	
	 - Throws			:  	
	 - Author			:	
	 - Creation Date	:	
	 - Description		:	
 
	 ********************************************************************************************************/

	
	@Override
	public String updateAddress(UserAccountBean useraccountbean) throws onlineBankingException {
		String result = "fail";
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			logger.info("Update Address - Connection Established Successfully");
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1=IQueryMapper.updateAddress;
			PreparedStatement s=con.prepareStatement(s1);
			s.setString(1, useraccountbean.getAddress());
			s.setLong(2, useraccountbean.getAccountNo());
			
			int status=s.executeUpdate();
			logger.info("Update Address - Statement Executed Successfully");
			if(status>0){
				logger.info("Update Address - address updated Successfully");
				result = "success";
			}
			else{
				logger.warn("Update Address - Failed to update Address.");
				result = "fail";
			}
			con.commit();
			con.close();
		}
		catch(Exception e){
			logger.error("Update Address - "+e.getMessage());
			throw new onlineBankingException("Failed to update Addresss.");
		}
		return result;
	
	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	raiseCheckBookRequest(long account)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/


	@Override
	public String raiseCheckBookRequest(long account) throws onlineBankingException {
		long service_id=0;
		String service_request=null;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			logger.info("Raise check book Request - Connection Established Successfully");
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			
			String sql=IQueryMapper.checkBookReqService;
			String seq_id=IQueryMapper.serviceTrackerrequest;
			
			ResultSet rs=stmt.executeQuery(seq_id);
			logger.info("Raise check book Request - Statement Executed Successfully");
			if(rs!=null){
				while(rs.next()){
					service_id=rs.getLong(1);
				}
			}
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setLong(1,service_id);
			ps.setString(2, "CheckBook");
			ps.setLong(3, account);
			ps.setString(4, "OpenState");
			
			int result=ps.executeUpdate();
			
			if(result>0){
				logger.info("Raise check book Request - Raise Checkbook request Successfully");
				service_request=Long.toString(service_id);
			}
			else{
				logger.warn("Raise check book Request - Failed to raise checkbook request");
				service_request="failed to generate check book request";
			}
			
		}
		catch(Exception e){
			logger.error("Raise check book Request - Failed to raise checkbook request - "+e.getMessage());
			throw new onlineBankingException("Failed to raise check book request.");
		}
		return service_request;
	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getAvailablePayees(long account)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/


	@Override
	public List<String> getAvailablePayees(long account) throws onlineBankingException{
		long payee_account=0;
		String name;
		List<String> list=new ArrayList<String>(25);
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			
			
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			logger.info("getAvailablePayees  - connection established successfully");
			
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.payeeList);
			pmstmt.setLong(1,account);
			ResultSet rs=pmstmt.executeQuery();
			logger.info("getAvailablePayees  - statement executed successfully");
			if(rs!=null){
				while(rs.next()){
					payee_account=rs.getLong(1);
					name=rs.getString(2);
					list.add(payee_account+"   "+name+"\n");
					logger.info("getAvailablePayees  - connection established successfully");
				}
			}
			//System.out.println(list);
		}
		catch(Exception e){
			logger.error("getAvailablePayee - "+e.getMessage());
			throw new onlineBankingException("Failed to get available payee");
		}
		return list;
	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addNewPayee(long account, long pAccount,String nickName)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	@Override
	public String addNewPayee(long account, long pAccount,String nickName) throws onlineBankingException{
		String result=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			logger.info("addNewPayee  - connection established successfully");
			
			//step3 create the statement object  
			Statement stmt=con.createStatement();
			String s1=IQueryMapper.payeeData;
			PreparedStatement ps=con.prepareStatement(s1);
			ps.setLong(1,account);
			ps.setLong(2, pAccount);
			ps.setString(3, nickName);
			int record=ps.executeUpdate();
			logger.info("addNewPayee  - statement executed successfully");
			
			if(record>0){
				logger.info("addNewPayee  - data retrieved successfully");
				result="true";
			}
			else{
				logger.warn("addNewPayee  - No data found");
				result="Payee Account Not Added";
			}
		}
		catch(Exception e){
			logger.error("addNewPayee  - "+e.getMessage());
			throw new onlineBankingException("Failed to add new payee.");
		}
		return result;
	}

	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getServiceDetails(long serviceId,long accountNumber)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	
	public String getServiceDetails(long serviceId,long accountNumber) throws onlineBankingException{
		StringBuilder str = new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			logger.info("getServiceDetails  - connection established successfully");
			//String query = "SELECT service_description,service_status FROM serviceTracker WHERE service_id = ? AND account_no = ?";
					
			PreparedStatement s = con.prepareStatement(IQueryMapper.ServiceId);
			s.setLong(1,serviceId);
			s.setLong(2,accountNumber);
			ResultSet rs = s.executeQuery();
			logger.info("getServiceDetails  - stateement executed successfully");
			if(rs.next()){
					str.append("\nService Description: ");
					str.append(rs.getString(1));
					str.append("\nService Status: ");
					str.append(rs.getString(2));
			}
			else str.append("Not Found");
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			logger.error("getServiceDetails  - " + e.getMessage());
			throw new onlineBankingException("Failed to get service Details");
		}
			return str.toString();
	}
		
		
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getAllServiceDetails(long accountNumber)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	
	public String getAllServiceDetails(long accountNumber) throws onlineBankingException{
		StringBuilder str = new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			logger.info("getAllServiceDetails  - connection established successfully");
			//String query = "SELECT service_id,service_description,service_status FROM serviceTracker WHERE account_no = ? AND (SYSDATE-service_raised_date)<=180";
					
			PreparedStatement s = con.prepareStatement(IQueryMapper.ServiceRequests);
			s.setLong(1,accountNumber);
			ResultSet rs = s.executeQuery();
			logger.info("getAllServiceDetails  - statement executed successfully");
			if(rs.next()){
				logger.info("getAllServiceDetails  - data retrieved successfully");
				str.append("Service Id: ");
				str.append(rs.getString(1));
				str.append("Service Description: ");
				str.append(rs.getString(2));
				str.append("\nService Status: ");
				str.append(rs.getString(3));
			}
			else str.append("Not Found");
				
			con.commit();
			con.close();
		}
		catch(Exception e){
			logger.error("getAllServiceDetails - "+e.getMessage());
				throw new onlineBankingException("Failed to get Service details");
		}
		return str.toString();
	}

	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getYearTransaction(int year)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/

	
	@Override
	public String generateNewAccount(UserAccountBean bean) throws onlineBankingException{
		String result = null;
		long accNum = 0;
			
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();
		logger.info("generateNewAccount  - connection established successfully");
		//String query = "INSERT INTO Account_master VALUES(seq_acc_num.NEXTVAL,?,?,SYSDATE)";
		//System.out.println("Reached insert");
		PreparedStatement s = con.prepareStatement(IQueryMapper.AccountDetails);
			
		s.setString(1, bean.getAccType());
		s.setLong(2, bean.getBalance());
			
		int rows = s.executeUpdate();
		logger.info("generateNewAccount  - statement executed successfully");
		if(rows>0){
			//query="SELECT seq_acc_num.CURRVAL FROM DUAL";
			s = con.prepareStatement(IQueryMapper.AccountSeq);
			ResultSet rs = s.executeQuery();
			logger.info("generateNewAccount  - statement executed  successfully");
			if(rs.next()){
				accNum = Long.parseLong(rs.getString(1));
				//query = "INSERT INTO Customer VALUES(?,?,?,?,?)";
				s = con.prepareStatement(IQueryMapper.CustomerDetails);
				s.setLong(1, accNum);
				s.setString(2, bean.getAccName());
				s.setString(3, bean.getEmail());
				s.setString(4, bean.getAddress());
				s.setString(5, bean.getPanCard());
				rows = s.executeUpdate();
				if(rows>0){
					result="success";
					logger.info("generateNewAccount  - Data Saved successfully");
				}
				else result="fail";
			}
			else{
				result="fail";
			}
		}
		else result="fail";
			
		con.commit();
		con.close();
		}
		catch(Exception e){
			logger.error("generateNewAccount - "+e.getMessage());
			throw new onlineBankingException("Failed to generate new account");
		}
		
			
		return result;
	}

	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	getYearTransaction(int year)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/


	
	@Override
	public String getYearTransaction(int year) throws onlineBankingException{
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			logger.info("generateYearransaction - Connection established successfully");
			Statement stmt=con.createStatement();
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.YearlyTransactions);
			pmstmt.setInt(1, year);
			ResultSet rs=pmstmt.executeQuery();
			logger.info("generateYearTransaction - Statement executed successfully");
			if(rs!=null){
				while(rs.next()){
					logger.info("generateYeartransaction - Data retrieved successfully");
					sb.append(rs.getString(1)+"              "+rs.getString(2)+"                "+rs.getString(3)+"\n");
				}
			}
		}
		catch(Exception e){
			logger.error("generateYearTransaction - "+e.getMessage());
			System.out.println(e.getMessage());
		}
		return sb.toString();
	}
	
	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	generateMonthTransaction(int month)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/


	@Override
	public String generateMonthTransaction(int month) throws onlineBankingException{
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			logger.info("generateMonthtransaction - Connection established successfully");
			Statement stmt=con.createStatement();
			//String sql=
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.MonthlyTransactions);
			pmstmt.setInt(1, month);
			ResultSet rs=pmstmt.executeQuery();
			logger.info("generateMonthTransaction -Statement executed successfully");
			//ResultSet rs=stmt.executeQuery("select transaction_id,account_no,transaction_date from transactions where extract(month from transaction_date)='"+month+"'");
			if(rs!=null){
				while(rs.next()){
					logger.info("generateMonthransaction - Data retrieved successfully");
					sb.append(rs.getString(1)+"              "+rs.getString(2)+"                "+rs.getString(3)+"\n");
				}
			}
		}
		catch(Exception e){
			logger.error("getMonthTransaction - "+e.getMessage());
			throw new onlineBankingException("No transactions available");
		}
		return sb.toString();
	}

	//------------------------ 1. Online Banking System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	generateDateTransaction(int date)
			 - Input Parameters	:	
			 - Return Type		:	
			 - Throws			:  	
			 - Author			:	
			 - Creation Date	:	
			 - Description		:	
			 ********************************************************************************************************/


	
	@Override
	public String generateDateTransaction(int date) throws onlineBankingException{
		StringBuilder sb=new StringBuilder();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			logger.info("generate Date transaction - Connection Established successfully");
			Statement stmt=con.createStatement();
			//ResultSet rs=stmt.executeQuery("select transaction_id,account_no,transaction_date from transactions where extract(date from transaction_date)='"+date+"'");
			PreparedStatement pmstmt=con.prepareStatement(IQueryMapper.DailyTransactions);
			pmstmt.setInt(1, date);
			ResultSet rs=pmstmt.executeQuery();
			logger.info("generate Date transaction - statement executed successfully");
			//ResultSet rs=stmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					sb.append(rs.getString(1)+"              "+rs.getString(2)+"                "+rs.getString(3)+"\n");
					logger.info("generate Date transaction - Data retrieved successfully");
				}
			}
		}
		catch(Exception e){
			logger.error("generate Date transaction - "+e.getMessage());
			throw new onlineBankingException("No Transacions available");
		}
		return sb.toString();
	}
	
}

