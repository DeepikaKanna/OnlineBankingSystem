package com.capgemini.onlineBanking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.onlineBanking.Util.RechargeDBConnection;
import com.capgemini.onlineBanking.bean.UserAccountBean;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserLoginDB implements IUserLogin {

	@Override
	public String LoginValidation(String userName, String pwd) {
		String password=null;
		String result = "false";
		String status=null;
		UserAccountBean rb=new UserAccountBean();
		long accountno;
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select account_no,login_password,lock_status from user_table where user_id='"+userName+"'"); 
		
		if(rs!=null){
			
			while(rs.next()){
				//System.out.println("hello");
				password=rs.getString(2);
				accountno=rs.getLong(1);
				status=rs.getString(3);
				//System.out.println(password);
				//System.out.println(pwd);
				
				if(password.equals(pwd)&&status.equals("U")){
					//rb.setAccNumber(accountno);
					result=String.valueOf(accountno);
					//System.out.println(result);
				}
				else{
					result="false";
					//System.out.println(result);
				}
				//sb.append(planname+"      "+Integer.toString(amount)+"\n");
				//System.out.println(details);
				
			}
		}
		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ 
			//msg=e.getMessage();
		}

		return result;
	}

	@Override
	public boolean getRegistered(UserAccountBean useraccountbean) throws onlineBankingException {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="insert into user_table values(?,?,?,?,?,?,'"+useraccountbean.getLockStatus()+"')";
			PreparedStatement s=con.prepareStatement(s1);
			//String s2="select rec_seq.nextval from dual";
			java.sql.Statement sw=con.createStatement();
			//ResultSet r1=sw.executeQuery(s2);
			//s.executeUpdate();
			s=con.prepareStatement(s1);
			//s.setInt(1,val);
			s.setLong(1,useraccountbean.getAccountNo());
			s.setLong(2,useraccountbean.getUserid());
			s.setString(3, useraccountbean.getLoginpassword());
			s.setString(4, useraccountbean.getSecurityQuestion());
		    s.setString(5,useraccountbean.getSecurityAnswer());
			s.setString(6,useraccountbean.getTransPassword());
			
			int result=s.executeUpdate();
			if(result>0){
				System.out.println("Values inserted successfully");
			}
			else{
				throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
			}
			}
			catch(Exception e){
				throw new onlineBankingException("Please Create your Bank Account to opt online Banking");
			}
			return false;
	}

	@Override
	public String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException {
		String trans_details=null;
		Long acc_no;
		long trans_id=0;
		StringBuilder sb=new StringBuilder();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");   
		//step2 create  the connection object  
		Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select account_no,transaction_id,transaction_date from transactions where account_no='"+account+"' and rownum<=5"); 
		
		if(rs!=null){
			while(rs.next()){
				//account=rs.getLong(1);
				trans_details=rs.getString(3);
				//System.out.println(trans_details);
				acc_no=rs.getLong(1);
				trans_id=rs.getLong(2);
				
				sb.append(acc_no+"                   "+trans_id+"                 "+trans_details+"\n");
			}
		}
		con.close();  
		  
	}catch(Exception e){ 
		//msg=e.getMessage();
	}
		// TODO Auto-generated method stub
		return sb.toString();
	}

	@Override
	public boolean validatePayee(long account, long paccount) {
		long payeraccount;
		int i=0;
		long paccounts[]=new long[100];
		boolean validatePayee=false;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select payee_account_no from payee_table where account_no='"+account+"'"); 
			if(rs!=null){
				while(rs.next()){
					payeraccount=rs.getLong(1);
					paccounts[i++]=payeraccount;
				}
			}
			for(i=0;i<paccounts.length;i++){
			if(paccounts[i]==paccount){
				validatePayee=true;
			}
			}
			//System.out.println(sb);
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		return validatePayee;
	}

	@Override
	public String transferFunds(long account, long paccount, int amount,String password) {
		int userBalance=0;
		int payeeBalance=0;
		String pwd=null;
		String fundTransfer="false";
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet resultset=stmt.executeQuery("select transaction_password from user_table where account_no='"+account+"'");
			if(resultset!=null){
				while(resultset.next()){
					pwd=resultset.getString(1);
				}
			}
			if(password.equals(pwd)){
			ResultSet rs=stmt.executeQuery("select account_balance from account_master where account_no='"+account+"'"); 
			if(rs!=null){
				while(rs.next()){
					userBalance=rs.getInt(1);
				}
			}
			ResultSet rs1=stmt.executeQuery("select account_balance from account_master where account_no='"+paccount+"'"); 
			if(rs1!=null){
				while(rs1.next()){
					payeeBalance=rs1.getInt(1);
				}
			}
			userBalance=userBalance-amount;
			payeeBalance=payeeBalance+amount;
			int userresult=stmt.executeUpdate("update account_master set account_balance='"+userBalance+"' where account_no='"+account+"'");
			int payeeresult=stmt.executeUpdate("update account_master set account_balance='"+payeeBalance+"' where account_no='"+paccount+"'");
			if(userresult>0&&payeeresult>0){
				fundTransfer="true";
			}
			else{
				fundTransfer="false";
			}
			}
			else{
				fundTransfer="Wrong Transaction Password";
			}
			con.close();  
		}
		catch(Exception e){
			
		}
		return fundTransfer;
	}

	@Override
	public void blockAccount(String userName, String pwd) {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			//int rs=stmt.executeQuery("select account_no,login_password,lock_status from user_table where user_id='"+userName+"'"); 
			int rs=stmt.executeUpdate("Update user_table set lock_status='L' where user_id='"+userName+"'");
			if(rs>0){
				System.out.println("Account Blocked");
			}
			else{
				System.out.println("Failed to recognize user_id");
			}
			//step5 close the connection object  
			con.close();  
			  
			}catch(Exception e){ 
				//msg=e.getMessage();
			}
		
	}

	
	@Override
	public boolean updateAddress(String address,long accNumber) {
		boolean result = false;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="update customer set address = '"+ address + "' where account_no = " + accNumber;
			PreparedStatement s=con.prepareStatement(s1);
			
			int status=s.executeUpdate();
			if(status>0)
				result = true;
			else result = false;
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return result;
		
	}

	@Override
	public boolean updateEmail(String emailId,long accNumber) {
		boolean result = false;
	
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");   
			//step2 create  the connection object  
			Connection con=RechargeDBConnection.getConnection();
			
			//("jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");  
			String s1="update customer set email = '"+ emailId + "' where accountno = " + accNumber;
			PreparedStatement s=con.prepareStatement(s1);
			
			int status=s.executeUpdate();
			if(status>0)
				result = true;
			else result = false;
			
			con.commit();
			con.close();
		}
		catch(Exception e){
			
		}
		return result;
	}
	
	
}

