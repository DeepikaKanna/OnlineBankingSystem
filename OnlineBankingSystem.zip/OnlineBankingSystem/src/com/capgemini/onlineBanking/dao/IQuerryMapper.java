package com.capgemini.onlineBanking.dao;

public interface IQuerryMapper {

}
