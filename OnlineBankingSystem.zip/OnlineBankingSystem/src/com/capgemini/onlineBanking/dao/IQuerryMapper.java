package com.capgemini.onlineBanking.dao;

public interface IQuerryMapper {
	public static final String GET_LOGIN_DETAILS = "SELECT account_no,login_password,lock_status FROM user_table WHERE user_id=?";
	public static final String INSERT_USER = "INSERT INTO user_table values(?,?,?,?,?,?,?)";
	public static final String GET_MINISTATEMENT = "SELECT account_no,transaction_id,transaction_date FROM transactions WHERE account_no=? AND rownum<=5";
	public static final String VALIDATE_PAYEE = "SELECT payee_account_no FROM payee_table WHERE account_no=?";
	public static final String TRANSFER_FUNDS = "SELECT transaction_password FROM user_table WHERE account_id=?";
	public static final String TRANSFER_FUNDS_2 = "SELECT account_balance FROM account_master WHERE account_no=?";
	public static final String TRANSFER_FUNDS_3 = "SELECT account_balance FROM account_master WHERE account_no=?";
	public static final String UPDATE_EMAIL = "UPDATE customer SET email = ? WHERE account_no = ?";
	public static final String UPDATE_ADDRESS = "UPDATE customer SET address = ? WHERE account_no = ?";
	public static final String BLOCK_ACCOUNT = "UPDATE user_table SET lock_status='L' WHERE user_id = ?";

}
