package com.capgemini.onlineBanking.dao;

public interface IQueryMapper {
	String validateUser="select account_no,login_password,lock_status from user_table where user_id=?";
	
	String registerUser="insert into user_table values(?,?,?,?,?,?,?)";
	
	String miniStatement="select account_no,transaction_id,transaction_date from transactions where account_no=? and rownum<=5";
	
	String validatePayee="select payee_account_no from payee_table where account_no=?";
	
	String validateTransPassword="select transaction_password from user_table where account_no=?";
	
	String userBalance="select account_balance from account_master where account_no=?";
	
	String payeeBalance="select account_balance from account_master where account_no=?";
	
	String updateUserBalance="update account_master set account_balance=? where account_no=?";
	
	String updatePayeeBalance="update account_master set account_balance=? where account_no=?";
	
	String blockAccount="Update user_table set lock_status='L' where user_id=?";
	
	String detailedStatement="select account_no,transaction_id,transaction_date from transactions where account_no=? and transaction_date between ? and ?";
	
	String updateEmail="update customers set email = ? where account_no =?";
	
	String updateAddress="update customers set address = ? where account_no =?";
	
	String checkBookReqService="insert into serviceTracker values(?,?,?,SYSDATE,?)";
	
	String serviceTrackerrequest="select service_seq_id.nextval from dual";
	
	String payeeList="select payee_account_no,nickname from payee_table where account_no=?";
	
	String payeeData="insert into payee_table values(?,?,?)";
	
	String transaction_id="select trans_seq_id.nextVal from dual";
	
	String transaction_Details="insert into transactions values(?,?,SYSDATE,?,?,?)";
	
	String AccountSeq="SELECT seq_acc_num.CURRVAL FROM DUAL";
	
	String CustomerDetails="INSERT INTO Customer VALUES(?,?,?,?,?)";
	
	String AccountDetails="INSERT INTO Account_master VALUES(seq_acc_num.NEXTVAL,?,?,SYSDATE)";
	
	String ServiceRequests="SELECT service_id,service_description,service_status FROM serviceTracker WHERE account_no = ? AND (SYSDATE-service_raised_date)<=180";

	String ServiceId="SELECT service_description,service_status FROM serviceTracker WHERE service_id = ? AND account_no = ?";

	String YearlyTransactions="select transaction_id,account_no,transaction_date from transactions where extract(year from transaction_date)=?";

	String MonthlyTransactions="select transaction_id,account_no,transaction_date from transactions where extract(month from transaction_date)=?";

	String DailyTransactions="select transaction_id,account_no,transaction_date from transactions where extract(day from transaction_date)=?";
}
