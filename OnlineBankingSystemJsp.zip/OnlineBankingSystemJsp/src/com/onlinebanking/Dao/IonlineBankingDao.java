package com.onlinebanking.Dao;

import java.sql.SQLException;
import java.util.ArrayList;




import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;

public interface IonlineBankingDao {

	public abstract ArrayList<Long> getAccounts(long userId) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getMiniStatement(long acc_no) throws OnlineBankingException;
	
	public abstract String validateUser(long userId,String password) throws OnlineBankingException, SQLException;
	
	public abstract boolean getRegistered(OnlineBankingBean userbean) throws OnlineBankingException, SQLException;
	
	public abstract ArrayList<OnlineBankingBean> getdetailedStatement(long acc_no,String fromDate,String toDate) throws OnlineBankingException;

	public abstract String getEmailId(long accountNo) throws OnlineBankingException;

	public abstract String updateEmailId(long acc_no, String email, String existingemail) throws OnlineBankingException;

	public abstract String getAddress(long accountNo) throws OnlineBankingException;

	public abstract String updateAddress(long acc_no, String address, String existingAddress) throws OnlineBankingException;
	
	public abstract void blockUserId(long key) throws OnlineBankingException;
	
	public abstract String validateSecretAnswer(String question, String answer, long userId) throws OnlineBankingException;
	
	public abstract String changePassword(String password,long userId) throws OnlineBankingException;
	
	public abstract String raiseCheckBookRequest(long accountNo, String description) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getServiceRequestDetails(long service_id) throws OnlineBankingException;

	public abstract ArrayList<Long> getPayeeAccounts(long uid) throws OnlineBankingException;

	public abstract String transferFunds(long accountNo, long payeeAccount, String transferDesc,long amount,String transpwd) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getAccountServiceRequestDetails(long acc_no) throws OnlineBankingException;

	public abstract String createAccount(OnlineBankingBean ob) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getTransactionYear(int year) throws OnlineBankingException;
	
	public abstract ArrayList<OnlineBankingBean> getTransactionMonth(int month) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getTransactionDate(int date) throws OnlineBankingException;
}
