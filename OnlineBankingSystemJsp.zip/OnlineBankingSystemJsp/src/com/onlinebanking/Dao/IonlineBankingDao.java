package com.onlinebanking.Dao;

import java.sql.SQLException;
import java.util.ArrayList;


import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;

public interface IonlineBankingDao {

	public abstract ArrayList<Long> getAccounts(long userId) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException;
	
	public abstract String validateUser(long userId,String password) throws OnlineBankingException, SQLException;
	
	public abstract boolean getRegistered(OnlineBankingBean userbean) throws OnlineBankingException, SQLException;
}
