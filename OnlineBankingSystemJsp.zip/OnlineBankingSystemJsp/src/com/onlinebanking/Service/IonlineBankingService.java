package com.onlinebanking.Service;

import java.sql.SQLException;
import java.util.ArrayList;


import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;

public interface IonlineBankingService {

	public abstract ArrayList<Long> getAccounts(long userId) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException;
	
	public abstract String validateUser(long userId, String pwd) throws OnlineBankingException, SQLException;
	
	public abstract boolean getRegistered(OnlineBankingBean userbean) throws OnlineBankingException, SQLException;

	public abstract ArrayList<OnlineBankingBean> getDetailedStatement(long acc_no,String fromDate,String toDate) throws OnlineBankingException;

	public abstract String getEmailId(long accountNo) throws OnlineBankingException;

	public abstract String updateEmail(long acc_no, String email, String existingemail) throws OnlineBankingException;

	public abstract String getAddress(long accountNo) throws OnlineBankingException;

	public abstract String updateAddress(long acc_no, String address, String existingAddress) throws OnlineBankingException;
	
	public abstract void blockUserId(long key) throws OnlineBankingException;
	
	public abstract String validateSecretAnswer(String question,String answer,long userId) throws OnlineBankingException;
	
	public abstract String changePassword(String password,long userId) throws OnlineBankingException;
	
	String raiseCheckBookRequest(long accountNo, String description) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getCheckBookService(long service_id) throws OnlineBankingException;

	public abstract ArrayList<Long> getPayeeAccounts(long uid) throws OnlineBankingException;

	public abstract String transferFunds(long accountNo, long payeeAccount, String transferDesc,long amount,String transpwd) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getCheckBookAccountService(long acc_no) throws OnlineBankingException;

	public abstract String createAccount(OnlineBankingBean ob) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getYearlyTransaction(int year) throws OnlineBankingException;
	
	public abstract ArrayList<OnlineBankingBean> getMonthlyTransaction(int month) throws OnlineBankingException;

	public abstract ArrayList<OnlineBankingBean> getDailyTransaction(int date) throws OnlineBankingException;

}
