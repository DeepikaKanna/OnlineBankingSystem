package com.onlinebanking.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Dao.IonlineBankingDao;
import com.onlinebanking.Dao.OnlineBankingDao;
import com.onlinebanking.Exception.OnlineBankingException;

public class OnlineBankingService implements IonlineBankingService{

	@Override
	public ArrayList<Long> getAccounts(long userId) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		
		ArrayList<Long> accounts=ibd.getAccounts(userId);
		
		return accounts;
	}

	@Override
	public ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> miniStatement=ibd.getMiniStatement(acc_no);
		return miniStatement;
	}
	
	@Override
	public String validateUser(long userId, String password) throws OnlineBankingException, SQLException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		String result = ibd.validateUser(userId, password);
		
		return result;
	}

	@Override
	public boolean getRegistered(OnlineBankingBean userbean) throws OnlineBankingException, SQLException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		boolean result = ibd.getRegistered(userbean);
		return result;
	}
	
	@Override
	public ArrayList<OnlineBankingBean> getDetailedStatement(long acc_no,String fromDate,String toDate) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> detailedStatement=ibd.getdetailedStatement(acc_no,fromDate,toDate);
		return detailedStatement;// TODO Auto-generated method stub
		
	}
	

	@Override
	public String getEmailId(long accountNo) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String email=ibd.getEmailId(accountNo);
		return email;
	}

	@Override
	public String updateEmail(long acc_no, String email, String existingemail) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String updateEmailId=ibd.getEmailId(acc_no,email,existingemail);
		return updateEmailId;
	}

	@Override
	public String getAddress(long accountNo) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String address=ibd.getAddress(accountNo);
		return address;
	}
	
	@Override
	public String updateAddress(long acc_no, String address, String existingAddress) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String updateEmailId=ibd.getAddressUpdate(acc_no,address,existingAddress);
		return updateEmailId;
	}

}
