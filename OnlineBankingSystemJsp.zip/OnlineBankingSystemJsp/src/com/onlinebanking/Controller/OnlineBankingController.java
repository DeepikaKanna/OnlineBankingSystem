package com.onlinebanking.Controller;

import java.awt.print.Printable;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;




import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Service.IonlineBankingService;
import com.onlinebanking.Service.OnlineBankingService;

/**
 * Servlet implementation class OnlineBankingController
 */
@WebServlet("/OnlineBankingController")
public class OnlineBankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnlineBankingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = null;
		OnlineBankingBean bean = new OnlineBankingBean();
		PrintWriter out = response.getWriter();
		RequestDispatcher rd=null;
		String operation=request.getParameter("action");
		System.out.println("Operation =" + operation);
		//HttpSession session=request.getSession(true);
		IonlineBankingService ibs=new OnlineBankingService();
		ArrayList<Long> accounts=new ArrayList<Long>();
		
		
		if(operation!=null && operation.equalsIgnoreCase("Login")){
			System.out.println("Reached login");
			session = request.getSession(true);
			long userId=Long.parseLong(request.getParameter("userID"));
			String pwd=request.getParameter("pwd");
			try {
				if(userId==12345l && pwd.equals("admin")){
					session.setAttribute("uname", "admin");
					session.setAttribute("userId", Long.toString(userId));
					System.out.println("Reached session");
					ServletContext context = getServletContext();
					rd = context.getRequestDispatcher("/homeAdmin.jsp");
					rd.include(request, response);
				}
				else{
					String result = ibs.validateUser(userId, pwd);
					if(!result.equals("fail")){
						accounts=ibs.getAccounts(userId);
						session.setAttribute("uname", result);
						session.setAttribute("userId", userId);
						session.setAttribute("accounts",accounts);
						ServletContext context = getServletContext();
						rd = context.getRequestDispatcher("/homeUser.jsp");
						rd.include(request, response);
					}
					else{
						session.setAttribute("uname", "fail");
						//System.out.println("\n\nreached else\n\n");
						ServletContext context = getServletContext();
						rd = context.getRequestDispatcher("/Login.jsp");
						rd.include(request, response);
					}
				}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
				ServletContext context = getServletContext();
				rd = context.getRequestDispatcher("/Error.jsp");
				rd.forward(request, response);
			}
		}
		else if(operation!=null&&operation.equalsIgnoreCase("FetchAccounts")){
			String accountDetails=request.getParameter("accounts").toString().replace("[", "").replace("]", "");
			List<String> myList = new ArrayList<String>(Arrays.asList(accountDetails.split(",")));
			System.out.println(accountDetails);
			request.setAttribute("accountDetails", myList);
			rd=request.getRequestDispatcher("/FetchAccounts.jsp");
			rd.include(request, response);
		}
		else if(operation!=null&&operation.equalsIgnoreCase("FetchDetailedAccounts")){
			String accountDetails=request.getParameter("accounts").toString().replace("[", "").replace("]", "");
			List<String> myList = new ArrayList<String>(Arrays.asList(accountDetails.split(",")));
			System.out.println(accountDetails);
			request.setAttribute("DetailedaccountDetails", myList);
			rd=request.getRequestDispatcher("/FetchDetailedAccounts.jsp");
			rd.include(request, response);
		}
		else if(operation!=null&&operation.equals("viewDetailedStatement")){
			long accountNo=Long.parseLong(request.getParameter("accountno"));
			request.setAttribute("account", accountNo);
			rd=request.getRequestDispatcher("/DetailedStatement.jsp");
			rd.include(request, response);
		}
		else if(operation!=null&&operation.equals("viewMiniStatement")){
			String acc_no=request.getParameter("accountno");
			try {
				ArrayList<OnlineBankingBean> miniStatement=ibs.getMiniStatement(acc_no);
				System.out.println(miniStatement);
				request.setAttribute("miniStatement", miniStatement);
				rd=request.getRequestDispatcher("/ViewMiniStatement.jsp");
				rd.forward(request, response);
			} catch (OnlineBankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else if(operation!=null&&operation.equals("GetDetailedStatement")){
			//System.out.println(request.getAttribute("accountNo"));
			//System.out.println(acc_no);
			try{
				long acc_no=Long.parseLong(request.getParameter("account"));
				String fromDate=request.getParameter("fromDate");
				String toDate=request.getParameter("toDate");
				
				//System.out.println(date);
					ArrayList<OnlineBankingBean> detailedStatement=ibs.getDetailedStatement(acc_no,fromDate,toDate);
					System.out.println(detailedStatement);
					request.setAttribute("detailedStatement", detailedStatement);
					rd=request.getRequestDispatcher("/ViewDetailedStatement.jsp");
					rd.forward(request, response);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else if(operation!=null && operation.equals("register")){
			System.out.println("Reached : " + operation);
			try {
				long accNum = Long.parseLong(request.getParameter("accNum"));
				long userId = Long.parseLong(request.getParameter("userId"));
				String pwd = request.getParameter("loginPwd");
				String color = request.getParameter("color");
				String transPwd = request.getParameter("transPwd");
				
				
				bean.setAccountNo(accNum);
				bean.setUserId(userId);
				bean.setLoginPwd(pwd);
				bean.setTransPwd(transPwd);
				bean.setColor(color);
				bean.setStatus("L");
				System.out.println("before method call");
				boolean result = ibs.getRegistered(bean);
				System.out.println("after method call");
				if(result==false){
					out.println("Failed to Register User....");
				}
				else{
					out.println("Registration Successfull....");
				}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
				ServletContext context = getServletContext();
				rd = context.getRequestDispatcher("/Error.jsp");
				rd.forward(request, response);
			}
			
		}
		else if(operation!=null&&operation.equalsIgnoreCase("updateEmail")){
			//IonlineBankingService ibs=new OnlineBankingService();
			//long acc_no=(long) session.getAttribute("userId");
			long acc_no=Long.parseLong(request.getParameter("userId"));
		//	ArrayList<Long> accounts=new ArrayList<Long>();
			try{
				accounts=ibs.getAccounts(acc_no);
	
				request.setAttribute("accounts",accounts);
				rd=request.getRequestDispatcher("/UpdateEmail.jsp");
				rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("EmailUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			System.out.println(accountNo);
			
			String email=ibs.getEmailId(accountNo);
			request.setAttribute("emailId", email);
			request.setAttribute("accountNo", accountNo);
			
			rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("ChangeEmail")){
			String email=request.getParameter("emailId");
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingemail=request.getParameter("existingemail");
			
			String updateEmail=ibs.updateEmail(acc_no,email,existingemail);
			if(updateEmail.equalsIgnoreCase("Updated")){
					out.println("updateEmail");
					rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			}
			
			
		}
		else if(operation!=null&&operation.equalsIgnoreCase("updateAddress")){
			long acc_no=Long.parseLong(request.getParameter("userId"));
			System.out.println(acc_no);
			
			//ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			
			request.setAttribute("accountNumbers",accounts);
			rd=request.getRequestDispatcher("/UpdateAddress.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		else if(operation!=null&&operation.equalsIgnoreCase("AddressUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			System.out.println(accountNo);
			
			String address=ibs.getAddress(accountNo);
			request.setAttribute("Address", address);
			request.setAttribute("accountNo", accountNo);
			
			rd=request.getRequestDispatcher("/AddressUpdation.jsp");
			rd.forward(request, response);
		}
		else if(operation!=null&&operation.equalsIgnoreCase("ChangeAddress")){
			String address=request.getParameter("Address");
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingAddress=request.getParameter("existingAddress");
			
			String updateAddress=ibs.updateAddress(acc_no,address,existingAddress);
			if(updateAddress.equalsIgnoreCase("Updated")){			
					out.println("updateAddress");
					rd=request.getRequestDispatcher("/AddressUpdation.jsp");
			}
		}
	}	
}